package textnumber;

import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class textnumberController {
    @FXML
    private TextField txtInput;

    @FXML
    private TextArea txtOutput;

    textnumberClass i;
    String display;

    public textnumberController(){
        txtInput =  new TextField();
        txtOutput = new TextArea();
        i = new textnumberClass();
        display = "";
    }
    @FXML
    protected void onReverseTextClick(){
        if (!txtInput.getText().isEmpty()){
            display = i.textBackwards(txtInput.getText());
        } else {
            display = "Enter a text or a number";
        }
        txtOutput.setText(display);
    }

    @FXML
    protected void onCountVowelClick(){
        if (!txtInput.getText().isEmpty()){
            int count = i.countVowels(txtInput.getText());
            display = "There are " + count + " vowels in " + txtInput.getText();
        } else {
            display = "Enter a text or a number";
        }
        txtOutput.setText(display);
    }

    @FXML
    protected void onDigitSumClick(){
        boolean isNumber = i.isNumber(txtInput.getText());

        if (isNumber && !txtInput.getText().isEmpty()) {
            int num = Integer.valueOf(txtInput.getText());
            int sum = i.digitSum(num);
            display = "The sum of all the digits for " + num + " is " + sum;
        } else {
            display = "You did NOT enter a number";
        }
        txtOutput.setText(display);
    }

    @FXML
    protected void onResetClick(){
        txtInput.setText("");
        txtOutput.setText("");
    }

}
